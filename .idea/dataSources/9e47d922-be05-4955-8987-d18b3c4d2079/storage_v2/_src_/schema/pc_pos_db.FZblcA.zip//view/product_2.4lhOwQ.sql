create definer = pc_pos_root@`%` view product_2 as
select `pc_pos_db`.`product`.`product_no`     AS `product_no`,
       `pc_pos_db`.`category`.`category_name` AS `category_name`,
       `pc_pos_db`.`product`.`product_name`   AS `product_name`,
       `pc_pos_db`.`product`.`price`          AS `price`,
       `pc_pos_db`.`product`.`stock`          AS `stock`
from `pc_pos_db`.`product`
         join `pc_pos_db`.`category`
where `pc_pos_db`.`product`.`category_no` = `pc_pos_db`.`category`.`category_no`;

